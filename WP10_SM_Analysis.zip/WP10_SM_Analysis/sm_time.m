% Starmaze 
% variables functions

% function SM_time
%  calculating time

function T= sm_time(a,b)
% calculates the time from the beginning to the end of the trial
T=b-a;

