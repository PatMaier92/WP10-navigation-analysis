% Starmaze WP3

function BR= sm_b_rot(y1,x1,y2,x2)

BR=mod((atan2d(y1,x1) - atan2d(y2,x2)),360);


                
