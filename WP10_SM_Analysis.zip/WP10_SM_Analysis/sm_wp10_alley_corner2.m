function [alley_x, alley_y]=sm_wp10_alley_corner2(alley_data,alleyNo,cornerNo,xmin,xmax,ymin,ymax)

alley_x=zeros(cornerNo,(alleyNo/2));
alley_y=zeros(cornerNo, (alleyNo/2));


for alley=1:(alleyNo/2)
    for corner=1:cornerNo
        alley_x(corner,alley)=alley_data(corner,alley);
    end
end
% alley_x=datanorm(alley_x,xmin,xmax);
for alley=1:(alleyNoTotal/2)
    for corner=1:cornerNo
        alley_y(corner,alley)=alley_data(corner,alley);
        alley_y(corner,alley)=datanorm(alley_y(corner,alley),ymin,ymax);
    end
end
   
end