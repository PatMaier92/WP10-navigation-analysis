function [sessionNo]=sm_wp10_inputSessionNo()
      sessionNo = str2num(input('Enter total number of sessions: ','s'));
end

