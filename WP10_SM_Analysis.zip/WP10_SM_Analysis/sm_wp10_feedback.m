function [fb]=sm_wp10_feedback(feedback)
s2='true';
fb=int8(strcmp(feedback,s2));

end