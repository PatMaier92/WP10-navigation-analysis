function sm_wp10_testfigure(polyshape_ow_array, goal_x1, goal_y1,goal_x2, goal_y2,goal_x3, goal_y3)

% % first figure
%     figure('Position',[500 200 580 500]);  
%     set(gca,'xtick',[0 1],'ytick',[0 1]);
%     plot(polyshape_array)  
%     axis([0 1 0 1])
%      title('Star-Maze')
%      hold on
%      viscircles([goal_x1 goal_y1], 0.001)
%      viscircles([goal_x2 goal_y2], 0.001)
%      viscircles([goal_x3 goal_y3], 0.001)
%      hold off
         
    % second figure
    figure('Position',[500 200 580 500]);  
    set(gca,'xtick',[0 1],'ytick',[0 1]);
    plot(polyshape_ow_array)
    axis([0 1 0 1])
    title('Star-Maze')
     hold on
     viscircles([goal_x1 goal_y1], 0.01)
     viscircles([goal_x2 goal_y2], 0.01)
     viscircles([goal_x3 goal_y3], 0.01)
     hold off
    
text(0.1,0.8,'Alley 5')
text(0.9,0.9,'Alley 2')
text(0.1,0.2,'Alley 4')
text(0.9,0.2,'Alley 3')
text(0.6,0.9,'Alley 1')
         
end