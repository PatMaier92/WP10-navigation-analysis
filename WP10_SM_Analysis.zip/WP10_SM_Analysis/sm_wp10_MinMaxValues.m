function [xmin,xmax,ymin,ymax]=sm_wp10_MinMaxValues(values)

xmin=values(1,1);
xmax=values(2,1);

ymin=values(1,2);
ymax=values(2,2);
end